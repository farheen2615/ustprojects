package com.pms.ust.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.cms.model.Customer;

import com.ust.pms.service.CustomerService;



@Controller
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	@RequestMapping("/addCustomer")
	public ModelAndView addCustomer() {
		return new ModelAndView("addCustomer","command",new Customer());
		
	}

	@RequestMapping("/saveCustomer")
	public String saveCustomer(Customer customer) {
		customerService.saveCustomer(customer);
		return "success";
	}
	

	@RequestMapping("/searchCustomerByIdForm")
	public ModelAndView searchCustomerByIdForm() {
		return new ModelAndView("searchCustomerByIdForm","command",new Customer());
	}
	
	@RequestMapping("/searchCustomerById")
	public ModelAndView searchCustomerById(Customer customer) {
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("searchCustomerByIdForm");
		int cId=customer.getCustomerId();
		if(customerService.isCustomerExists(cId)) {
			Customer customerDetails=customerService.getCustomer(cId) ;
			modelAndView.addObject("command", customerDetails);
		}
		else {
			modelAndView.addObject("command", new Customer());
			modelAndView.addObject("msg", "Customer with customer id:"+cId+"does not exists");
			
		}
		return modelAndView;
	}
	
	@RequestMapping("/deleteCustomerById")
	public ModelAndView deleteCustomerById(Customer customer) {
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("searchCustomerByIdForm");
		modelAndView.addObject("command", new Customer());
		
		int cId=customer.getCustomerId();
		if(customerService.isCustomerExists(cId)) {
			customerService.deleteCustomer(cId) ;
			modelAndView.addObject("msg", "Customer with customer id:"+cId+"deleted customer successfully");
		}
		else {
			
			modelAndView.addObject("msg", "Customer with customer id:"+cId+"does not exists");
			
		}
		return modelAndView;
	}
	// fetch all products
	@RequestMapping("/viewAllCustomers")
	public ModelAndView viewAllCustomers() {
		List<Customer> customers=customerService.getCustomers();
		return new ModelAndView("viewAllCustomers","customers",customers);
	}

}
	

	
		

