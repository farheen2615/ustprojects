package com.ust.pms.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.cms.model.Customer;

import com.ust.pms.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	public void saveCustomer(Customer customer) {
		// This will save the customer in database
		customerRepository.save(customer);
	}

	public List<Customer> getCustomers() {
		return (List<Customer>) customerRepository.findAll();
	}

	public Customer getCustomer(Integer customerId) {
	Optional<Customer> customer=customerRepository.findById(customerId);
		return customer.get();
	}

	public void deleteCustomer(Integer customerId) {
		customerRepository.deleteById(customerId);
		;
	}

	public void updateCustomer(Customer customer) {
		// save or update
		customerRepository.save(customer);
	}

	public boolean isCustomerExists(int customerId) {
		return customerRepository.existsById(customerId); 	
		}

}
