
# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price** | **Integer** | product cost |  [optional]
**productId** | **Integer** | product id is pk and unique |  [optional]
**productName** | **String** | product name  |  [optional]
**quantityOnHand** | **Integer** | product quantity |  [optional]



