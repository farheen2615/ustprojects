# ProductControllerApi

All URIs are relative to *https://localhost:9999*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteProductUsingDELETE**](ProductControllerApi.md#deleteProductUsingDELETE) | **DELETE** /product/{productId} | deleteProduct
[**filterProductByPriceUsingGET**](ProductControllerApi.md#filterProductByPriceUsingGET) | **GET** /product/filterProductByPrice/{lowerRange}/{upperRange} | Find product by giving lower and upper bound
[**getProductUsingGET**](ProductControllerApi.md#getProductUsingGET) | **GET** /product/{productId} | Find all the products 
[**getProductsUsingGET**](ProductControllerApi.md#getProductsUsingGET) | **GET** /product | Find product by product id
[**saveProductUsingPOST**](ProductControllerApi.md#saveProductUsingPOST) | **POST** /product | saveProduct
[**searchProductByNameUsingGET**](ProductControllerApi.md#searchProductByNameUsingGET) | **GET** /product/searchByProductName/{productName} | Find product by name
[**updateProductUsingPUT**](ProductControllerApi.md#updateProductUsingPUT) | **PUT** /product | updateProduct


<a name="deleteProductUsingDELETE"></a>
# **deleteProductUsingDELETE**
> String deleteProductUsingDELETE(productId)

deleteProduct

### Example
```java
// Import classes:
//import com.swagger.client.codegen.rest.invoker.ApiException;
//import com.swagger.client.codegen.rest.api.ProductControllerApi;


ProductControllerApi apiInstance = new ProductControllerApi();
Integer productId = 56; // Integer | productId
try {
    String result = apiInstance.deleteProductUsingDELETE(productId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductControllerApi#deleteProductUsingDELETE");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **Integer**| productId |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="filterProductByPriceUsingGET"></a>
# **filterProductByPriceUsingGET**
> List&lt;Product&gt; filterProductByPriceUsingGET(lowerRange, upperRange)

Find product by giving lower and upper bound

you can filter product on price for ex:1000-2000

### Example
```java
// Import classes:
//import com.swagger.client.codegen.rest.invoker.ApiException;
//import com.swagger.client.codegen.rest.api.ProductControllerApi;


ProductControllerApi apiInstance = new ProductControllerApi();
Integer lowerRange = 56; // Integer | lowerRange
Integer upperRange = 56; // Integer | upperRange
try {
    List<Product> result = apiInstance.filterProductByPriceUsingGET(lowerRange, upperRange);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductControllerApi#filterProductByPriceUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lowerRange** | **Integer**| lowerRange |
 **upperRange** | **Integer**| upperRange |

### Return type

[**List&lt;Product&gt;**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getProductUsingGET"></a>
# **getProductUsingGET**
> Product getProductUsingGET(productId)

Find all the products 

You will get all the products from here

### Example
```java
// Import classes:
//import com.swagger.client.codegen.rest.invoker.ApiException;
//import com.swagger.client.codegen.rest.api.ProductControllerApi;


ProductControllerApi apiInstance = new ProductControllerApi();
Integer productId = 56; // Integer | productId
try {
    Product result = apiInstance.getProductUsingGET(productId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductControllerApi#getProductUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **Integer**| productId |

### Return type

[**Product**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getProductsUsingGET"></a>
# **getProductsUsingGET**
> List&lt;Product&gt; getProductsUsingGET()

Find product by product id

Give product id to search for a particular id

### Example
```java
// Import classes:
//import com.swagger.client.codegen.rest.invoker.ApiException;
//import com.swagger.client.codegen.rest.api.ProductControllerApi;


ProductControllerApi apiInstance = new ProductControllerApi();
try {
    List<Product> result = apiInstance.getProductsUsingGET();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductControllerApi#getProductsUsingGET");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;Product&gt;**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="saveProductUsingPOST"></a>
# **saveProductUsingPOST**
> String saveProductUsingPOST(product)

saveProduct

### Example
```java
// Import classes:
//import com.swagger.client.codegen.rest.invoker.ApiException;
//import com.swagger.client.codegen.rest.api.ProductControllerApi;


ProductControllerApi apiInstance = new ProductControllerApi();
Product product = new Product(); // Product | product
try {
    String result = apiInstance.saveProductUsingPOST(product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductControllerApi#saveProductUsingPOST");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product** | [**Product**](Product.md)| product |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="searchProductByNameUsingGET"></a>
# **searchProductByNameUsingGET**
> List&lt;Product&gt; searchProductByNameUsingGET(productName)

Find product by name

Hey, You can search product on the basis of name

### Example
```java
// Import classes:
//import com.swagger.client.codegen.rest.invoker.ApiException;
//import com.swagger.client.codegen.rest.api.ProductControllerApi;


ProductControllerApi apiInstance = new ProductControllerApi();
String productName = "productName_example"; // String | productName
try {
    List<Product> result = apiInstance.searchProductByNameUsingGET(productName);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductControllerApi#searchProductByNameUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productName** | **String**| productName |

### Return type

[**List&lt;Product&gt;**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="updateProductUsingPUT"></a>
# **updateProductUsingPUT**
> String updateProductUsingPUT(product)

updateProduct

### Example
```java
// Import classes:
//import com.swagger.client.codegen.rest.invoker.ApiException;
//import com.swagger.client.codegen.rest.api.ProductControllerApi;


ProductControllerApi apiInstance = new ProductControllerApi();
Product product = new Product(); // Product | product
try {
    String result = apiInstance.updateProductUsingPUT(product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductControllerApi#updateProductUsingPUT");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product** | [**Product**](Product.md)| product |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

