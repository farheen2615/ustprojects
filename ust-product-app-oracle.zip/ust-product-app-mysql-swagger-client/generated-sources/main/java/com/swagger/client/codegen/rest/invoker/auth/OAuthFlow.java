package com.swagger.client.codegen.rest.invoker.auth;

public enum OAuthFlow {
    accessCode, implicit, password, application
}