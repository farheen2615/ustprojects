package com.ust;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PaymentController {
	
	@RequestMapping("/payment")
	public String doPayment() {
		return "Welcome";
	}
	
}
