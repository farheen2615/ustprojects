package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Project;



@RestController
public class HelloController {
	
	
	@Value("${companey.name}")
	private String companyName;
	
	@Value("${companey.location}")
	private String companyLocation;
		
	
	@Value("${welcome.message}")
	private String welcomeMessage;
	
	@RequestMapping("/hello")
	public String sayHelloo() {
		return "Welcome to first spring hello app2";
	}
	
	
	@RequestMapping("/ex")
	public String Example4() {
		return "hello from hello controller and the welcome message is:" +welcomeMessage;
	}
	
	@RequestMapping("/cmp")
	public String cmps() {
		return "Company Location:"+ companyLocation;
	}
	
	@Autowired
	Project project;
	
	@RequestMapping("/project")
	public String project() {
		return "Version is:"+project.getVersion()+'\n'
				+"Name:"+project.getName()+'\n'
				+"Location:"+project.getLocation()+'\n'
				+"TeamLead:"+project.getTeamlead()+'\n'
				+"TeamSize:"+project.getTeamsize()+'\n';
	}
}

