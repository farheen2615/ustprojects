package com.ust.kafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.kafka.service.KafkaSender;

@RestController
@RequestMapping("/kafka")
public class MyController {
	@Autowired
	KafkaSender kafkaSender;
	
	@GetMapping("/sendMessage/{message}")
	public String sendMessage(@PathVariable("message") String message) {
		kafkaSender.sendMessageUsingKafka(message);
		return "Message send to kafka topic successfully";
	}
	@GetMapping("/sendMessage")
	public String sendMessage2(@RequestParam("message") String message) {
		kafkaSender.sendMessageUsingKafka(message);
		return "Message send to kafka topic successfully";
	}

}
