package com.ust.kafka.service;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaSender {
 @Autowired
 private KafkaTemplate<String,String> kafkaTemplate;
 
 @Autowired
 DataSource dataSource;
}
