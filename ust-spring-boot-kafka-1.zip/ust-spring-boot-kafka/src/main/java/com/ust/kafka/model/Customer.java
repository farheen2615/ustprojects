package com.ust.kafka.model;

import javax.persistence.Entity;

@Entity
//@Data
public class Customer {

}
