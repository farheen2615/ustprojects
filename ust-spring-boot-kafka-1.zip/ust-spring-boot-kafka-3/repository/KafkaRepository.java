package com.ust.kafka.repository;

import org.springframework.data.repository.CrudRepository;

import com.ust.kafka.model.KafkaModel;





public interface KafkaRepository extends CrudRepository<KafkaModel, Integer> {

}
