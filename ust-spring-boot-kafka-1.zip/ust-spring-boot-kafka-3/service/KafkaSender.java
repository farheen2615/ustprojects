package com.ust.kafka.service;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.ust.kafka.model.KafkaModel;
import com.ust.kafka.repository.KafkaRepository;

@Service
public class KafkaSender {
	@Autowired
 private KafkaTemplate<String,String> kafkaTemplate;
	 
	 @Autowired
		KafkaRepository kafkaRepository;

		public void saveKafka(KafkaModel kModel) {
			// This will save the product in database
			kafkaRepository.save(kModel);
		}
	
// private final String TOPIC_NAME="UST";
	//here it will create a new topic because its not presend in cmd
 private final String TOPIC_NAME="USTKOCHI";
 
 public void sendMessageUsingKafka(String message) {
	 kafkaTemplate.send(TOPIC_NAME,message);
 }
 
}
