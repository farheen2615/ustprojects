package com.ust.kafka.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class KafkaModel {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int KafkaId;
	private String KafkaName;
	
}

