package com.ust.kafka.repository;

import org.springframework.data.repository.CrudRepository;

import com.ust.kafka.model.Message;

public interface KafkaRepository extends CrudRepository<Message, Integer> {

}
