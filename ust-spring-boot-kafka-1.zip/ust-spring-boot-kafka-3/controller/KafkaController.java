package com.ust.kafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.kafka.model.KafkaModel;
import com.ust.kafka.service.KafkaSender;

@RestController
@RequestMapping("/far-kafka")
public class KafkaController {

	@Autowired
	private KafkaSender kafkaSender;
	
	
	@GetMapping("/sendMessage/{message}")
	public String sendMessage(@PathVariable("message") String message) {
		kafkaSender.sendMessageUsingKafka(message);
		return "Message sent to kafka Topic UST successfully";
	}
	
	
	@GetMapping("/sendMessage")
	public String sendMessage1(@RequestParam("message") String message) {
		kafkaSender.sendMessageUsingKafka(message);
		return "Message sent to kafka Topic UST successfully";
	}
	
	
		

		  @PostMapping
			public String saveKafka(@RequestBody KafkaModel kModel) {
		    	 System.out.println("Saving Kafka Details:"+ kModel);
		    	 kafkaSender.saveKafka(kModel);
				return "Saving Kafka Data";
			}
}
