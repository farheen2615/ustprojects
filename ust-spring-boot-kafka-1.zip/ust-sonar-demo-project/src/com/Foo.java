
  package com;
  
 public class Foo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Hello World");

int target = -5;
int num = 3;

target =- num;  // Noncompliant; target = -3. Is that really what's meant?
target =+ num; // Noncompliant; target = 3
}}