package com.ust.spring.kafka.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.ust.spring.kafka.model.Customer;

@Service
public class KafkaReceiver {
		
Logger logger=LoggerFactory.getLogger(KafkaReceiver.class);

@KafkaListener(topics="${kafka.topic.name}",groupId = "${kafka.consumer.group.id}")
public void receiveMessage(Customer customer) {
	logger.info("#### Customer Data Received Received:" +customer);
	
	
}
}
