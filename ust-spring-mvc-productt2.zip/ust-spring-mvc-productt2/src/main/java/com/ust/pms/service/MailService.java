package com.ust.pms.service;

import com.ust.pms.model.Mail;

public interface MailService {
public void send(String fromAddress, String toAddress, String subject, String content) throws Exception;
	

}
