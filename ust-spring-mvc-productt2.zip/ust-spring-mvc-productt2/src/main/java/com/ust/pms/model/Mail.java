package com.ust.pms.model;

import lombok.Data;

@Data
public class Mail {
	private String name;
	private String phone;
	private String email;
	private String address;
	private String subject;
	private String content;
}
