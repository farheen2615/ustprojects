package com.pms.ust.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Numbers;
import com.ust.pms.service.NumberService;

@Controller
public class IndexController {
	@Autowired
	NumberService numberService;

	@RequestMapping("/index")
	public ModelAndView index() {
		ModelAndView view = new ModelAndView();
		view.addObject("username", "Jay");
		view.setViewName("kapoor");
		return view;
	}

	@RequestMapping("/helloo")
	public String Kapoor() {
		return "kapoor";
	}

	@RequestMapping("/hello")
	public String Hello() {
		return "Hello";
	}

	@RequestMapping("/welcome")
	public String app() {
		return "Welcome";
	}

	@RequestMapping("/results")
	public ModelAndView result(Numbers numbers) {
		int res = numbers.getFirstNumber() + numbers.getSecondNumber();
		return new ModelAndView("result", "sumresult", res);

	}

	@RequestMapping("/addNumbers")
	public ModelAndView addNumbers() {
		return new ModelAndView("addNumbersForm", "name", "farheen");
	}

	@RequestMapping("/result")
	public ModelAndView results(Numbers numbers) {
		int sum = numbers.getFirstNumber() + numbers.getSecondNumber() + numbers.getThirdNumber()
				+ numbers.getFourNumber() + numbers.getFiveNumber();
		numbers.setResult(sum);
		numberService.saveNumbers(numbers);
		return new ModelAndView("result", "sum", sum);
	}

}
