package com.pms.ust.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Product;
import com.ust.pms.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	
	@RequestMapping("/addProduct")
	public ModelAndView addProduct() {
		return new ModelAndView("addProduct","command",new Product());
	}

	@RequestMapping("/saveProduct")
	public String saveProduct(Product product) {
		productService.saveProduct(product);
		return "success";
	}
	@RequestMapping("/searchProductByIdForm")
	public ModelAndView searchProductByIdForm() {
		return new ModelAndView("searchProductByIdForm","command",new Product());
	}
	@RequestMapping("/searchProductById")
	public ModelAndView seachProductById(Product product) {
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");
		int pId=product.getProductId();
		if(productService.isProductExists(pId)) {
			Product productDetails=productService.getProduct(pId) ;
			modelAndView.addObject("command", productDetails);
		}
		else {
			modelAndView.addObject("command", new Product());
			modelAndView.addObject("msg", "Product with product id:"+pId+"does not exists");
			
		}
		return modelAndView;
	}
	
	@RequestMapping("/deleteProductById")
	public ModelAndView deleteProductById(Product product) {
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");
		modelAndView.addObject("command", new Product());
		
		int pId=product.getProductId();
		if(productService.isProductExists(pId)) {
			productService.deleteProduct(pId) ;
			modelAndView.addObject("msg", "Product with product id:"+pId+"deleted product successfully");
		}
		else {
			
			modelAndView.addObject("msg", "Product with product id:"+pId+"does not exists");
			
		}
		return modelAndView;
	}
	// fetch all products
	@RequestMapping("/viewAllProducts")
	public ModelAndView viewAllProducts() {
		List<Product> products=productService.getProducts();
		return new ModelAndView("viewAllProducts","products",products);
	}

}
	
		

