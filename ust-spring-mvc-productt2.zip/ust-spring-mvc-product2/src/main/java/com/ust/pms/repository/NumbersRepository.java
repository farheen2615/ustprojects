package com.ust.pms.repository;

import org.springframework.data.repository.CrudRepository;

import com.ust.pms.model.Numbers;

public interface NumbersRepository extends CrudRepository<Numbers, Integer> {

}
