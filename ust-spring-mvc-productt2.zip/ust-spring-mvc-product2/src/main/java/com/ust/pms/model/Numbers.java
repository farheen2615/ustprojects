package com.ust.pms.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Numbers {
	@Id
	@GeneratedValue
	private int attempt;
    private int firstNumber;
	private int secondNumber;
	private int thirdNumber;
	private int fourNumber;
	private int fiveNumber;
	private int result;
}
