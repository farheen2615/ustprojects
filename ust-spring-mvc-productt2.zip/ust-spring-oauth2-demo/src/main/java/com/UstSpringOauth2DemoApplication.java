package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UstSpringOauth2DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UstSpringOauth2DemoApplication.class, args);
	}

}
