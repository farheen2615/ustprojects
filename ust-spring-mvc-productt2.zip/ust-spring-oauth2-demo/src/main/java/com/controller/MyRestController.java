package com.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.UserProfile;

@RestController
public class MyRestController {

	@RequestMapping("/ust/userDetails")
	public ResponseEntity<UserProfile> getUserDetails(){
		User user=(User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserProfile profile=new UserProfile();
		profile.setName(user.getUsername());
		profile.setEmail("farheensiddique2615@gmail.com");
		
		return ResponseEntity.ok(profile);
	}
}

//localhost:8084/userDetails
