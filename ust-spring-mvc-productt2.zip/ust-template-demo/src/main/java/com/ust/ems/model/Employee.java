package com.ust.ems.model;

import lombok.Data;

@Data
public class Employee {
 private int employeeId;
 private String employeeName;
}
